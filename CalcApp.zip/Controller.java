
package CalcApp1;

// packages to support currency calculations
import java.math.BigDecimal;
import java.text.NumberFormat;

// JavaFX packages
import javafx.event.ActionEvent;

// default imports from SceneBuilder
import javafx.scene.control.Button;
import javafx.fxml.FXML;       // marks instance variables and methods that refer to JavaFX GUI components in the fxml file
import javafx.scene.control.TextField;

public class Controller {

    private static final NumberFormat currency =
            NumberFormat.getCurrencyInstance();


    private BigDecimal US_TO_CAN_RATE = new BigDecimal(1.32); // 1

    @FXML
    private TextField dollarsInputField;

    @FXML
    private TextField canadianOutputField;

    @FXML
    private void convertButtonPressed(ActionEvent event)
    {
        try
        {
           BigDecimal amount = new BigDecimal(dollarsInputField.getText());
            BigDecimal convertedAmount = amount.multiply(US_TO_CAN_RATE);

            // set the output text field value
            canadianOutputField.setText(currency.format(convertedAmount));
        }
        catch (NumberFormatException e)
        {
            dollarsInputField.setText("Enter amount.");
            dollarsInputField.selectAll();
            dollarsInputField.requestFocus();
        }

    } // end of convertButtonPressed

    @FXML
    private void clearButtonPressed(ActionEvent event)
    {
        try
        {
            dollarsInputField.setText("");
            canadianOutputField.setText("");
        }
        catch (NumberFormatException e)
        {          }

    } // end of clearButtonPressed

}
